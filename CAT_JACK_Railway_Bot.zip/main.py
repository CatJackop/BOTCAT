import os
import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
PREFIX = os.getenv("PREFIX", ".")
TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True

class CatJack(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=PREFIX,
            intents=intents,
            help_command=None,
            case_insensitive=True
        )

    async def setup_hook(self):
        for name in (
            "cogs.moderation",
            "cogs.admin",
            "cogs.tickets",
            "cogs.giveaways",
            "cogs.music",
            "cogs.fun",
            "cogs.motivation",
            "cogs.utilities",
            "cogs.social",
        ):
            try:
                await self.load_extension(name)
                print(f"Loaded {name}")
            except Exception as e:
                print(f"Failed {name}: {e}")
        try:
            synced = await self.tree.sync()
            print(f"Synced {len(synced)} slash commands")
        except Exception as e:
            print(f"Slash sync failed: {e}")

    async def on_ready(self):
        print(f"CAT JACK online as {self.user} ({self.user.id})")
        print(f"Prefix: {PREFIX}")

bot = CatJack()

@bot.command(name="help")
async def prefix_help(ctx):
    embed = discord.Embed(
        title="🐱 CAT JACK — Help Center",
        description="Use the category commands below. Prefix: `.` • Slash commands: `/`",
        color=0xFFD21F
    )
    embed.add_field(name="🛡️ Moderation", value="`.ban` `.kick` `.timeout` `.warn` `.purge`", inline=False)
    embed.add_field(name="⚙️ Admin / Server", value="`.setup` `.settings` `.welcome` `.logs` `.autorole`", inline=False)
    embed.add_field(name="🎫 Tickets", value="`.ticket` `.close` `.claim` `.add` `.remove` `.transcript`", inline=False)
    embed.add_field(name="🎁 Giveaways", value="`.giveaway` `.gstart` `.gend` `.reroll` `.gcancel`", inline=False)
    embed.add_field(name="🎵 Music", value="`.play` `.pause` `.resume` `.skip` `.stop` `.queue`", inline=False)
    embed.add_field(name="🎮 Fun", value="`.8ball` `.coinflip` `.dice` `.joke` `.meme` `.rps`", inline=False)
    embed.add_field(name="💪 Motivation", value="`.motivate` `.quote` `.goal` `.success` `.inspire`", inline=False)
    embed.add_field(name="🔧 Utilities", value="`.ping` `.userinfo` `.serverinfo` `.avatar` `.remind`", inline=False)
    embed.add_field(name="⭐ Leveling / Social", value="`.rank` `.level` `.leaderboard` `.rep` `.profile`", inline=False)
    embed.set_footer(text="CATJack.gg • CAT JACK")
    await ctx.send(embed=embed)

@bot.tree.command(name="help", description="Open the CAT JACK help menu")
async def slash_help(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🐱 CAT JACK — Help Center",
        description="Use the category commands below. Prefix: `.` • Slash commands: `/`",
        color=0xFFD21F
    )
    embed.add_field(name="🛡️ Moderation", value="Ban, kick, timeout, warn, purge", inline=False)
    embed.add_field(name="⚙️ Admin / Server", value="Setup, welcome, logs, roles, settings", inline=False)
    embed.add_field(name="🎫 Tickets", value="Create, close, claim, add, remove, transcript", inline=False)
    embed.add_field(name="🎁 Giveaways", value="Start, end, reroll, cancel, entries", inline=False)
    embed.add_field(name="🎵 Music", value="Play, pause, resume, skip, queue, volume", inline=False)
    embed.add_field(name="🎮 Fun", value="Games, memes, jokes, polls and reactions", inline=False)
    embed.add_field(name="💪 Motivation", value="Quotes, goals, inspiration and success", inline=False)
    embed.add_field(name="🔧 Utilities", value="Ping, userinfo, serverinfo, avatar, reminders", inline=False)
    embed.add_field(name="⭐ Leveling / Social", value="XP, rank, leaderboard, reputation, profile", inline=False)
    embed.set_footer(text="CATJack.gg • CAT JACK")
    await interaction.response.send_message(embed=embed)

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing. Add it in Railway Variables.")

bot.run(TOKEN)
