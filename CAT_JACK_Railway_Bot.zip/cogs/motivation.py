import random
from discord.ext import commands

QUOTES = [
    "Keep going. Small progress is still progress.",
    "Focus on what you can do today.",
    "Consistency beats waiting for perfect.",
    "You can start again and keep moving forward.",
    "Believe in the work you are putting in."
]

class Motivation(commands.Cog):
    def __init__(self, bot): self.bot=bot

    @commands.hybrid_command(name="motivate")
    async def motivate(self, ctx):
        await ctx.send(f"💪 **{random.choice(QUOTES)}**")

    @commands.hybrid_command(name="quote")
    async def quote(self, ctx):
        await ctx.send(f"✨ **{random.choice(QUOTES)}**")

    @commands.hybrid_command(name="inspire")
    async def inspire(self, ctx):
        await ctx.send(f"🌟 **{random.choice(QUOTES)}**")

async def setup(bot): await bot.add_cog(Motivation(bot))
