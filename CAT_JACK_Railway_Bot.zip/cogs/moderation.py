import discord
from discord.ext import commands
from datetime import timedelta

class Moderation(commands.Cog):
    def __init__(self, bot): self.bot=bot

    @commands.hybrid_command(name="ban")
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason="No reason provided"):
        await member.ban(reason=reason)
        await ctx.send(f"🔨 Banned **{member}** — {reason}")

    @commands.hybrid_command(name="kick")
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason="No reason provided"):
        await member.kick(reason=reason)
        await ctx.send(f"👢 Kicked **{member}** — {reason}")

    @commands.hybrid_command(name="timeout")
    @commands.has_permissions(moderate_members=True)
    async def timeout(self, ctx, member: discord.Member, minutes: int=10, *, reason="No reason provided"):
        await member.timeout(timedelta(minutes=minutes), reason=reason)
        await ctx.send(f"⏱️ Timed out **{member}** for **{minutes}m**.")

    @commands.hybrid_command(name="purge")
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int):
        amount=max(1,min(amount,100))
        await ctx.channel.purge(limit=amount+1)
        await ctx.send(f"🧹 Deleted **{amount}** messages.", delete_after=4)

async def setup(bot): await bot.add_cog(Moderation(bot))
