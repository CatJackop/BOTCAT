from discord.ext import commands

class Social(commands.Cog):
    def __init__(self, bot): self.bot=bot

    @commands.hybrid_command(name="profile")
    async def profile(self, ctx, member=None):
        member = member or ctx.author
        await ctx.send(f"⭐ **{member.display_name}** — CAT JACK profile")

    @commands.hybrid_command(name="rank")
    async def rank(self, ctx):
        await ctx.send(f"⭐ **{ctx.author.display_name}** — Level system ready.")

async def setup(bot): await bot.add_cog(Social(bot))
