import asyncio
import random
from discord.ext import commands

class Giveaways(commands.Cog):
    def __init__(self, bot): self.bot=bot

    @commands.hybrid_command(name="giveaway")
    @commands.has_permissions(manage_guild=True)
    async def giveaway(self, ctx, seconds: int, winners: int, *, prize: str):
        msg=await ctx.send(f"🎁 **GIVEAWAY!**\nPrize: **{prize}**\nWinners: **{winners}**\nReact with 🎉\nEnds in **{seconds}s**")
        await msg.add_reaction("🎉")
        await asyncio.sleep(max(1,seconds))
        msg=await ctx.channel.fetch_message(msg.id)
        users=[u async for u in msg.reactions[0].users() if not u.bot]
        if not users:
            await ctx.send("🎁 Giveaway ended with no valid entries.")
            return
        picked=random.sample(users, min(winners,len(users)))
        await ctx.send("🏆 Winner(s): " + ", ".join(u.mention for u in picked))

async def setup(bot): await bot.add_cog(Giveaways(bot))
