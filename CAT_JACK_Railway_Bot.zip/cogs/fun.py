import random
import discord
from discord.ext import commands

class Fun(commands.Cog):
    def __init__(self, bot): self.bot=bot

    @commands.hybrid_command(name="coinflip")
    async def coinflip(self, ctx):
        await ctx.send(f"🪙 **{random.choice(['Heads','Tails'])}**")

    @commands.hybrid_command(name="dice")
    async def dice(self, ctx):
        await ctx.send(f"🎲 You rolled **{random.randint(1,6)}**")

    @commands.hybrid_command(name="8ball")
    async def eightball(self, ctx, *, question: str):
        await ctx.send(f"🎱 **{random.choice(['Yes.','No.','Maybe.','Definitely.','Ask again later.'])}**")

    @commands.hybrid_command(name="choose")
    async def choose(self, ctx, *, choices: str):
        items=[x.strip() for x in choices.split("|") if x.strip()]
        await ctx.send(f"🎯 **{random.choice(items) if items else 'Give me choices separated by |'}**")

async def setup(bot): await bot.add_cog(Fun(bot))
