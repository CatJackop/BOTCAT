import discord
from discord.ext import commands

class Utilities(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command()
    async def ping(self, ctx):
        await ctx.send(embed=discord.Embed(title="🐱 CAT JACK", description=f"🏓 Pong! `{round(self.bot.latency*1000)}ms`", color=0xFFD21F))

    @commands.hybrid_command(name="serverinfo")
    async def serverinfo(self, ctx):
        g = ctx.guild
        e = discord.Embed(title=f"🏠 {g.name}", description=f"Members: **{g.member_count}**\nOwner: <@{g.owner_id}>", color=0xFFD21F)
        await ctx.send(embed=e)

    @commands.hybrid_command(name="userinfo")
    async def userinfo(self, ctx, member: discord.Member=None):
        member = member or ctx.author
        e = discord.Embed(title=f"👤 {member}", color=0xFFD21F)
        e.add_field(name="ID", value=member.id)
        e.add_field(name="Joined", value=discord.utils.format_dt(member.joined_at, "R") if member.joined_at else "Unknown")
        await ctx.send(embed=e)

    @commands.hybrid_command(name="avatar")
    async def avatar(self, ctx, member: discord.Member=None):
        member = member or ctx.author
        e = discord.Embed(title=f"🖼️ {member.display_name}", color=0xFFD21F)
        e.set_image(url=member.display_avatar.url)
        await ctx.send(embed=e)

async def setup(bot): await bot.add_cog(Utilities(bot))
