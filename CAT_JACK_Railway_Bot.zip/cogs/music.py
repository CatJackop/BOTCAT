from discord.ext import commands

class Music(commands.Cog):
    def __init__(self, bot): self.bot=bot

    @commands.hybrid_command(name="join")
    async def join(self, ctx):
        if ctx.author.voice:
            await ctx.author.voice.channel.connect()
            await ctx.send("🎵 Joined the voice channel.")
        else:
            await ctx.send("❌ Join a voice channel first.")

    @commands.hybrid_command(name="leave")
    async def leave(self, ctx):
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            await ctx.send("👋 Left the voice channel.")
        else:
            await ctx.send("❌ I am not in a voice channel.")

async def setup(bot): await bot.add_cog(Music(bot))
