import discord
from discord.ext import commands

class Tickets(commands.Cog):
    def __init__(self, bot): self.bot=bot

    @commands.hybrid_command(name="ticket")
    async def ticket(self, ctx):
        guild=ctx.guild
        overwrites={guild.default_role: discord.PermissionOverwrite(view_channel=False),
                    ctx.author: discord.PermissionOverwrite(view_channel=True, send_messages=True)}
        ch=await guild.create_text_channel(f"ticket-{ctx.author.name}", overwrites=overwrites)
        await ch.send(f"🎫 Ticket opened for {ctx.author.mention}. Use `.close` when finished.")
        await ctx.send(f"🎫 Created {ch.mention}", ephemeral=True if isinstance(ctx, commands.Context) else False)

    @commands.hybrid_command(name="close")
    async def close(self, ctx):
        if ctx.channel.name.startswith("ticket-"):
            await ctx.send("🔒 Closing ticket...")
            await ctx.channel.delete()
        else:
            await ctx.send("❌ This is not a CAT JACK ticket channel.")

async def setup(bot): await bot.add_cog(Tickets(bot))
