# CAT JACK — Railway Discord Bot

Railway-ready Discord bot using discord.py.

Prefix: `.`
Slash commands: `/`

Included categories:
- Moderation
- Admin / Server
- Tickets
- Giveaways
- Music
- Fun
- Motivation
- Utilities
- Leveling / Social

No dashboard or website.

## Railway variables
Required:
- DISCORD_TOKEN

Optional:
- DATABASE_URL
- PREFIX (defaults to `.`)

## Run
pip install -r requirements.txt
python main.py

The bot syncs slash commands on startup.
